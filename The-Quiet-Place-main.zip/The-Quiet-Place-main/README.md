Ola...
Esse repositório contem os codigos em HTML de um site que eu fiz para um fos filmes de Terror/Suspense mais bem feitoa nos ultimos anos.
Estou falandi da incrivel trilogia Um Lugar Silencioso.
Espero que voces gostem.
